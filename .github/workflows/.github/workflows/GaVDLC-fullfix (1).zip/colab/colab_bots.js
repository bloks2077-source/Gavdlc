// GaVDLC mineflayer backend for Google Colab
// Usage: node colab_bots.js
const mineflayer = require('mineflayer');
const express = require('express');
const app = express();
app.use(express.json());

const bots = new Map();
let spamInterval = null;

app.post('/api/spawn', (req, res) => {
  const { host, port, count, mode, username } = req.body;
  const n = Math.min(count || 1, 150);
  for (let i = 0; i < n; i++) {
    const name = (username || 'Bot') + '_' + (i + 1);
    spawnBot(host, port || 25565, name, mode);
  }
  res.json({ ok: true, spawned: n });
});

app.post('/api/command', (req, res) => {
  const { cmd, mode } = req.body;
  bots.forEach(bot => {
    if (bot && bot.chat) {
      try { bot.chat(cmd); } catch (e) {}
    }
  });
  res.json({ ok: true });
});

app.post('/api/spam', (req, res) => {
  const { host, port, message, rate, count } = req.body;
  stopSpam();
  const n = Math.min(count || 10, 150);
  for (let i = 0; i < n; i++) {
    spawnBot(host, port || 25565, 'Spam_' + (i + 1), 'SPAM');
  }
  const ms = Math.max(50, 1000 / (rate || 1));
  spamInterval = setInterval(() => {
    bots.forEach(bot => {
      if (bot && bot.chat) {
        try { bot.chat(message || 'spam'); } catch (e) {}
      }
    });
  }, ms);
  res.json({ ok: true, rate, bots: n });
});

app.post('/api/stop', (req, res) => {
  stopSpam();
  bots.forEach(bot => { try { bot.quit(); } catch (e) {} });
  bots.clear();
  res.json({ ok: true });
});

function spawnBot(host, port, username, mode) {
  const bot = mineflayer.createBot({
    host, port, username,
    auth: 'offline',
    hideErrors: true
  });
  bot.on('spawn', () => bots.set(username, bot));
  bot.on('kicked', () => setTimeout(() => spawnBot(host, port, username, mode), 3000));
  bot.on('end', () => setTimeout(() => spawnBot(host, port, username, mode), 5000));
  bot.on('error', () => {});
}

function stopSpam() {
  if (spamInterval) { clearInterval(spamInterval); spamInterval = null; }
}

app.listen(8080, () => console.log('GaVDLC bots backend on :8080'));
