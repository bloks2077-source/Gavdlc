# GaVDLC Bots on Google Colab

1. Upload colab_bots.js and package.json
2. Run:
```
!npm install
!node colab_bots.js &
!curl -s ifconfig.me
```
3. Use the IP:8080 as bots.backend in the client

Note: Colab free tier has limited uptime and may block outbound game ports.
