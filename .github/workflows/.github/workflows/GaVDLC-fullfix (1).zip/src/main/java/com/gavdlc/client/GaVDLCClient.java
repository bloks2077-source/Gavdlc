package com.gavdlc.client;
import com.gavdlc.gui.ClickGuiScreen;
import com.gavdlc.gui.BotChatScreen;
import com.gavdlc.gui.MainMenuScreen;
import com.gavdlc.logic.ModuleLogic;
import com.gavdlc.logic.AutoWinLogic;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.TitleScreen;
import org.lwjgl.glfw.GLFW;
public class GaVDLCClient implements ClientModInitializer {
    private boolean shiftWasDown, mWasDown;
    @Override public void onInitializeClient() {
        ScreenEvents.AFTER_INIT.register((c,s,w,h)->{ if(s instanceof TitleScreen) c.setScreen(new MainMenuScreen()); });
        ClientTickEvents.END_CLIENT_TICK.register(c->{
            if(c.player==null) return;
            ModuleLogic.tick(c);
            AutoWinLogic.tick(c);
            long win=c.getWindow().getHandle();
            boolean shift=GLFW.glfwGetKey(win,GLFW.GLFW_KEY_RIGHT_SHIFT)==GLFW.GLFW_PRESS;
            boolean m=GLFW.glfwGetKey(win,GLFW.GLFW_KEY_M)==GLFW.GLFW_PRESS;
            if(shift && !shiftWasDown){
                if(c.currentScreen instanceof ClickGuiScreen) c.setScreen(null);
                else if(c.currentScreen==null) c.setScreen(new ClickGuiScreen());
            }
            if(m && !mWasDown && c.currentScreen==null){
                c.setScreen(new BotChatScreen());
            }
            shiftWasDown=shift;
            mWasDown=m;
        });
    }
}
