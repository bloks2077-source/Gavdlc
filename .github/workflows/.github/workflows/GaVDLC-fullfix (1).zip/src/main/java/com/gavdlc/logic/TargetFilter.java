package com.gavdlc.logic;
import com.gavdlc.module.Settings;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
public final class TargetFilter {
    public static boolean accept(LivingEntity e) {
        if (e instanceof PlayerEntity pe) {
            if (pe.isSpectator() || pe.isCreative()) return false;
            boolean invis = pe.isInvisible();
            boolean naked = isNaked(pe);
            if (invis && !Settings.getBool("aura.targetInvisible", true)) return false;
            if (naked && !Settings.getBool("aura.targetNaked", true)) return false;
            if (!invis && !naked && !Settings.getBool("aura.targetPlayers", true)) return false;
            return true;
        }
        if (e instanceof MobEntity) return Settings.getBool("aura.targetMobs", false);
        return false;
    }
    private static boolean isNaked(PlayerEntity pe) {
        for (ItemStack s : pe.getInventory().armor) if (!s.isEmpty()) return false;
        return true;
    }
}
