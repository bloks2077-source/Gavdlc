package com.gavdlc.bots;
import com.gavdlc.module.Settings;
import java.util.*;
public final class BotManager {
    public static final List<String> BOTS = new ArrayList<>();
    public static final List<String> CHAT_LOG = new ArrayList<>();
    public static List<String> suggestions = new ArrayList<>();

    public static void startLocal(String host, int port, int count) {
        String mode = Settings.getStr("bots.mode", "ULTRASAFE");
        LocalBotRunner.start(host, port, count, mode);
    }
    public static void stopLocal() { LocalBotRunner.stop(); }

    public static void onInput(String input) {
        suggestions = CommandHelper.suggest(input);
    }
    public static void sendChat(String msg) {
        if (msg == null || msg.isEmpty()) return;
        suggestions.clear();
        if (CommandHelper.isHelp(msg)) {
            CHAT_LOG.add("[Help]\n" + CommandHelper.helpText());
            return;
        }
        CHAT_LOG.add("[You] " + msg);
        if (CHAT_LOG.size() > 50) CHAT_LOG.remove(0);
        LocalBotRunner.chat(msg);
        processCommand(msg);
    }
    private static void processCommand(String msg) {
        String low = msg.toLowerCase();
        if (low.startsWith("/mine")) Settings.setBool("bots.autoMine", true);
        else if (low.equals("/warden")) Settings.setBool("bots.autoWarden", true);
        else if (low.startsWith("/craft")) {
            Settings.setBool("bots.autoCraft", true);
            Settings.setStr("bots.craftItem", msg.length() > 7 ? msg.substring(7).trim() : "diamond");
        }
        else if (low.equals("/stop")) {
            Settings.setBool("bots.autoMine", false);
            Settings.setBool("bots.autoWarden", false);
            Settings.setBool("bots.autoCraft", false);
            stopLocal();
        }
        else if (low.equals("/ultrasafe")) Settings.setStr("bots.mode", "ULTRASAFE");
        else if (low.equals("/default")) Settings.setStr("bots.mode", "Default");
        else if (low.startsWith("/start")) {
            String[] p = msg.split(" ");
            String host = p.length > 1 ? p[1] : "localhost";
            int port = p.length > 2 ? Integer.parseInt(p[2]) : 25565;
            int count = p.length > 3 ? Integer.parseInt(p[3]) : 10;
            startLocal(host, port, count);
        }
    }
}
