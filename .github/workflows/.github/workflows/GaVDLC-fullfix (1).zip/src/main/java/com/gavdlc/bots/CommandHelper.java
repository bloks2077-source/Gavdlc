package com.gavdlc.bots;
import java.util.*;
import java.util.stream.Collectors;
public final class CommandHelper {
    public static final List<String> ALL = Arrays.asList(
        "/help", "/mine diamond", "/mine redstone", "/mine ancient_debris", "/mine iron",
        "/warden", "/craft", "/me", "/stop", "/follow", "/home", "/goto", "/drop",
        "/equip", "/eat", "/pearl", "/crystal", "/obby", "/totem", "/sprint",
        "/sneak", "/jump", "/ultrasafe", "/default"
    );
    public static List<String> suggest(String input) {
        if (input == null || input.isEmpty()) return Collections.emptyList();
        String low = input.toLowerCase();
        return ALL.stream().filter(c -> c.toLowerCase().startsWith(low)).limit(8).collect(Collectors.toList());
    }
    public static String helpText() {
        return String.join("\n", ALL);
    }
    public static boolean isHelp(String input) {
        return input != null && (input.equalsIgnoreCase("/h") || input.equalsIgnoreCase("/help") || input.toLowerCase().startsWith("/h"));
    }
}
