package com.gavdlc.module;
import java.util.*;
public final class Settings {
    private static final Map<String, Float> F = new HashMap<>();
    private static final Map<String, Boolean> B = new HashMap<>();
    private static final Map<String, String> S = new HashMap<>();
    static {
        // AttackAura targets
        B.put("aura.targetPlayers", true);
        B.put("aura.targetNaked", true);
        B.put("aura.targetInvisible", true);
        B.put("aura.targetMobs", false);
        B.put("aura.targetAnimals", false);
        F.put("aura.cps", 8f);
        F.put("aura.maxRange", 6f);
        F.put("aura.attackRange", 3.8f);
        B.put("aura.onlyJump", false);
        F.put("aura.onlyJumpRange", 6f);
        // AUTOWIN
        B.put("autowin.enabled", false);
        F.put("autowin.eatHp", 10f);
        F.put("autowin.fleeHp", 6f);
        F.put("autowin.aimSpeed", 1f);
        F.put("autowin.cps", 10f);
        F.put("autowin.range", 6f);
        S.put("autowin.apiKey", "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");
        // Bots
        B.put("bots.enabled", false);
        S.put("bots.mode", "ULTRASAFE"); // ULTRASAFE or Default
        F.put("bots.count", 10f);
        S.put("bots.chat", "");
        B.put("bots.autoMine", false);
        B.put("bots.autoWarden", false);
        B.put("bots.autoCraft", false);
        S.put("bots.craftItem", "diamond");
    }
    public static float get(String k, float d) { return F.getOrDefault(k, d); }
    public static void set(String k, float v) { F.put(k, v); }
    public static boolean getBool(String k, boolean d) { return B.getOrDefault(k, d); }
    public static void setBool(String k, boolean v) { B.put(k, v); }
    public static String getStr(String k, String d) { return S.getOrDefault(k, d); }
    public static void setStr(String k, String v) { S.put(k, v); }
}
