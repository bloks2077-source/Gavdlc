package com.gavdlc.module;
public class Module {
    public final String name, category, description;
    public boolean enabled;
    public Module(String name, String category, String description) {
        this.name = name; this.category = category; this.description = description; this.enabled = false;
    }
    public void toggle() { enabled = !enabled; }
}
