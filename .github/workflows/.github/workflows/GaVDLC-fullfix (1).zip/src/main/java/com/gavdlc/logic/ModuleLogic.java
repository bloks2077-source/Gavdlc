package com.gavdlc.logic;

import com.gavdlc.module.Module;
import com.gavdlc.module.ModuleManager;
import com.gavdlc.module.Settings;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public final class ModuleLogic {
    private ModuleLogic() {}
    private static long lastAttack;
    private static long lastCrystal;
    private static long lastTotem;
    private static double savedGamma = -1;

    public static void tick(MinecraftClient mc) {
        if (mc == null || mc.player == null || mc.world == null || mc.interactionManager == null) return;
        Module m;

        m = ModuleManager.get("AttackAura");
        Module aim = ModuleManager.get("AimAssist");
        boolean auraOn = m != null && m.enabled;
        boolean aimOn = aim != null && aim.enabled;
        if (auraOn || aimOn) {
            boolean onlyJump = Settings.getBool("aura.onlyJump", false) || "OnlyJump".equals(Settings.getStr("aura.rotation", ""));
            boolean jumping = !mc.player.isOnGround() && mc.player.getVelocity().y > 0;
            if (!(onlyJump && !jumping && auraOn)) {
                float range = onlyJump ? Settings.get("aura.onlyJumpRange", 6f) : Settings.get("aura.maxRange", 6f);
                range = MathHelper.clamp(range, 3f, 10f);
                List<LivingEntity> targets = findTargets(mc, range);
                if (!targets.isEmpty()) {
                    LivingEntity target = targets.get(0);
                    float speed = auraOn ? Settings.get("aura.legitSpeed", 0.08f) * 4f : Settings.get("aim.speed", 0.18f);
                    if (!onlyJump) smoothLook(mc, target.getPos().add(0, target.getHeight() * 0.5, 0), speed);
                    if (auraOn) {
                        float cps = Settings.get("aura.cps", 8f);
                        long delay = (long) (1000f / Math.max(1f, cps));
                        if (System.currentTimeMillis() - lastAttack > delay) {
                            if (onlyJump) {
                                for (LivingEntity t : targets) {
                                    if (mc.player.distanceTo(t) <= range) {
                                        try { mc.interactionManager.attackEntity(mc.player, t); } catch (Throwable ignored) {}
                                    }
                                }
                                mc.player.swingHand(Hand.MAIN_HAND);
                            } else if (mc.player.distanceTo(target) <= Settings.get("aura.attackRange", 3f)) {
                                try {
                                    mc.interactionManager.attackEntity(mc.player, target);
                                    mc.player.swingHand(Hand.MAIN_HAND);
                                } catch (Throwable ignored) {}
                            }
                            lastAttack = System.currentTimeMillis();
                        }
                    }
                }
            }
        }

        m = ModuleManager.get("AutoCristal");
        if (m != null && m.enabled && System.currentTimeMillis() - lastCrystal > Settings.get("crystal.speed", 50f)) {
            try { doCrystal(mc); } catch (Throwable ignored) {}
            lastCrystal = System.currentTimeMillis();
        }

        m = ModuleManager.get("AutoTotem");
        if (m != null && m.enabled && System.currentTimeMillis() - lastTotem > 200) {
            try { doTotem(mc); } catch (Throwable ignored) {}
            lastTotem = System.currentTimeMillis();
        }

        m = ModuleManager.get("Sprint");
        if (m != null && m.enabled && mc.player.forwardSpeed > 0 && !mc.player.isSneaking()) mc.player.setSprinting(true);

        m = ModuleManager.get("NoFall");
        if (m != null && m.enabled && mc.player.fallDistance > 2.5f) mc.player.fallDistance = 0;

        m = ModuleManager.get("Speed");
        if (m != null && m.enabled && mc.player.isOnGround() && mc.player.forwardSpeed != 0) {
            mc.player.setVelocity(mc.player.getVelocity().multiply(1.05, 1, 1.05));
        }

        m = ModuleManager.get("FullBright");
        if (m != null && m.enabled) {
            if (savedGamma < 0) savedGamma = mc.options.getGamma().getValue();
            mc.options.getGamma().setValue(16.0);
        } else if (savedGamma >= 0) {
            mc.options.getGamma().setValue((double) savedGamma);
            savedGamma = -1;
        }

        m = ModuleManager.get("Jesus");
        if (m != null && m.enabled && mc.player.isTouchingWater() && !mc.player.isSneaking())
            mc.player.setVelocity(mc.player.getVelocity().x, 0.1, mc.player.getVelocity().z);

        m = ModuleManager.get("Spider");
        if (m != null && m.enabled && mc.player.horizontalCollision)
            mc.player.setVelocity(mc.player.getVelocity().x, 0.2, mc.player.getVelocity().z);
    }

    private static void doCrystal(MinecraftClient mc) {
        float range = Settings.get("crystal.searchRange", 4f);
        if (Settings.getBool("crystal.breakFirst", true)) {
            EndCrystalEntity crystal = findCrystal(mc, range);
            if (crystal != null) {
                lookAt(mc, crystal.getPos().add(0, 0.5, 0));
                mc.interactionManager.attackEntity(mc.player, crystal);
                mc.player.swingHand(Hand.MAIN_HAND);
                return;
            }
        }
        int crystalSlot = findHotbar(mc, Items.END_CRYSTAL);
        if (crystalSlot >= 0) {
            BlockPos base = findCrystalBase(mc, range);
            if (base != null) {
                selectSlot(mc, crystalSlot);
                lookAt(mc, Vec3d.ofCenter(base).add(0, 0.5, 0));
                BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(base).add(0, 0.5, 0), Direction.UP, base, false);
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
                mc.player.swingHand(Hand.MAIN_HAND);
                return;
            }
        }
        if (Settings.getBool("crystal.placeObby", true)) {
            int obbySlot = findHotbar(mc, Items.OBSIDIAN);
            if (obbySlot >= 0) {
                BlockPos spot = findObbySpot(mc, range);
                if (spot != null) {
                    selectSlot(mc, obbySlot);
                    BlockPos below = spot.down();
                    lookAt(mc, Vec3d.ofCenter(below).add(0, 0.5, 0));
                    BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(below).add(0, 0.5, 0), Direction.UP, below, false);
                    mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
                    mc.player.swingHand(Hand.MAIN_HAND);
                }
            }
        }
    }

    private static void doTotem(MinecraftClient mc) {
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        int slot = findHotbar(mc, Items.TOTEM_OF_UNDYING);
        if (slot >= 0 && mc.getNetworkHandler() != null) {
            int prev = mc.player.getInventory().getSelectedSlot();
            mc.player.getInventory().setSelectedSlot(slot);
            mc.getNetworkHandler().sendPacket(new net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket(
                net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
            mc.player.getInventory().setSelectedSlot(prev);
        }
    }

    private static EndCrystalEntity findCrystal(MinecraftClient mc, double range) {
        Box box = mc.player.getBoundingBox().expand(range);
        EndCrystalEntity best = null; double bestD = range;
        for (Entity e : mc.world.getOtherEntities(mc.player, box, ent -> ent instanceof EndCrystalEntity)) {
            double d = mc.player.distanceTo(e);
            if (d < bestD) { bestD = d; best = (EndCrystalEntity) e; }
        }
        return best;
    }

    private static BlockPos findCrystalBase(MinecraftClient mc, double range) {
        BlockPos p = mc.player.getBlockPos(); int r = (int) range;
        for (int x = -r; x <= r; x++) for (int y = -2; y <= 2; y++) for (int z = -r; z <= r; z++) {
            BlockPos base = p.add(x, y, z);
            if (mc.player.squaredDistanceTo(Vec3d.ofCenter(base)) > range * range) continue;
            if (!mc.world.getBlockState(base).isOf(Blocks.OBSIDIAN) && !mc.world.getBlockState(base).isOf(Blocks.BEDROCK)) continue;
            if (!mc.world.getBlockState(base.up()).isAir()) continue;
            if (!mc.world.getOtherEntities(null, new Box(base.up()).expand(0.1)).isEmpty()) continue;
            return base;
        }
        return null;
    }

    private static BlockPos findObbySpot(MinecraftClient mc, double range) {
        BlockPos p = mc.player.getBlockPos(); int r = (int) range;
        for (int x = -r; x <= r; x++) for (int y = -1; y <= 1; y++) for (int z = -r; z <= r; z++) {
            BlockPos pos = p.add(x, y, z);
            if (mc.player.squaredDistanceTo(Vec3d.ofCenter(pos)) > range * range) continue;
            if (!mc.world.getBlockState(pos).isAir()) continue;
            if (!mc.world.getBlockState(pos.down()).isSolidBlock(mc.world, pos.down())) continue;
            if (!mc.world.getBlockState(pos.up()).isAir()) continue;
            if (pos.equals(mc.player.getBlockPos())) continue;
            return pos;
        }
        return null;
    }

    private static List<LivingEntity> findTargets(MinecraftClient mc, double range) {
        List<LivingEntity> list = new ArrayList<>();
        Box box = mc.player.getBoundingBox().expand(range);
        for (Entity e : mc.world.getOtherEntities(mc.player, box, ent -> ent instanceof LivingEntity && ent.isAlive())) {
            LivingEntity living = (LivingEntity) e;
            if (living instanceof PlayerEntity pe) {
                if (pe.isSpectator() || pe.isCreative()) continue;
                if (!Settings.getBool("aura.targetPlayers", true)) continue;
            } else {
                if (!Settings.getBool("aura.targetMobs", false)) continue;
            }
            if (mc.player.distanceTo(living) <= range) list.add(living);
        }
        list.sort((a, b) -> Double.compare(mc.player.distanceTo(a), mc.player.distanceTo(b)));
        return list;
    }

    private static void smoothLook(MinecraftClient mc, Vec3d target, float speed) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d diff = target.subtract(eye);
        float wantYaw = (float) Math.toDegrees(Math.atan2(-diff.x, diff.z));
        float wantPitch = (float) -Math.toDegrees(Math.atan2(diff.y, Math.hypot(diff.x, diff.z)));
        mc.player.setYaw(MathHelper.lerpAngleDegrees(speed, mc.player.getYaw(), wantYaw));
        mc.player.setPitch(MathHelper.clamp(MathHelper.lerp(speed, mc.player.getPitch(), wantPitch), -90, 90));
    }

    private static void lookAt(MinecraftClient mc, Vec3d target) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d diff = target.subtract(eye);
        mc.player.setYaw((float) Math.toDegrees(Math.atan2(-diff.x, diff.z)));
        mc.player.setPitch(MathHelper.clamp((float) -Math.toDegrees(Math.atan2(diff.y, Math.hypot(diff.x, diff.z))), -90, 90));
    }

    private static int findHotbar(MinecraftClient mc, net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }

    private static void selectSlot(MinecraftClient mc, int slot) {
        if (slot != mc.player.getInventory().getSelectedSlot() && slot >= 0 && slot < 9 && mc.getNetworkHandler() != null) {
            mc.player.getInventory().setSelectedSlot(slot);
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        }
    }
}
