package com.gavdlc.bots;

import com.gavdlc.module.Settings;
import java.util.*;
import java.util.concurrent.*;

/**
 * Local bots running on the same PC/phone.
 * ULTRASAFE: minimal threads, only chat relay.
 * Default: more active but still local.
 */
public final class LocalBotManager {
    private static final ExecutorService POOL = Executors.newCachedThreadPool();
    private static final List<LocalBot> ACTIVE = Collections.synchronizedList(new ArrayList<>());
    private static volatile boolean running;

    public static void start(int count, String mode) {
        stop();
        running = true;
        int n = Math.min(count, 150);
        boolean ultra = "ULTRASAFE".equals(mode);
        for (int i = 0; i < n; i++) {
            LocalBot bot = new LocalBot("Bot_" + (i + 1), ultra);
            ACTIVE.add(bot);
            POOL.submit(bot);
        }
    }

    public static void stop() {
        running = false;
        for (LocalBot b : ACTIVE) b.stop();
        ACTIVE.clear();
    }

    public static void broadcast(String msg) {
        for (LocalBot b : ACTIVE) b.queueChat(msg);
    }

    public static int activeCount() { return ACTIVE.size(); }
    public static boolean isRunning() { return running; }

    static class LocalBot implements Runnable {
        final String name;
        final boolean ultraSafe;
        final Queue<String> chatQueue = new ConcurrentLinkedQueue<>();
        volatile boolean alive = true;

        LocalBot(String name, boolean ultra) {
            this.name = name;
            this.ultraSafe = ultra;
        }

        void queueChat(String msg) { chatQueue.offer(msg); }
        void stop() { alive = false; }

        @Override
        public void run() {
            while (alive && running) {
                try {
                    String msg = chatQueue.poll();
                    if (msg != null) {
                        // In ULTRASAFE just log; in Default could do more
                        BotManager.CHAT_LOG.add("[" + name + "] " + msg);
                        if (BotManager.CHAT_LOG.size() > 100) BotManager.CHAT_LOG.remove(0);
                    }
                    Thread.sleep(ultraSafe ? 500 : 100);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }
    }
}
