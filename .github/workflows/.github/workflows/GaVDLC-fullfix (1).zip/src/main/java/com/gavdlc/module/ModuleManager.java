package com.gavdlc.module;
import java.util.*;
import java.util.stream.Collectors;
public class ModuleManager {
    public static final List<Module> MODULES = new ArrayList<>();
    static {
        add("AttackAura","Combat","Attacks nearby entities with aim");
        add("AimAssist","Combat","Smooth aim assist");
        add("AutoCristal","Combat","Auto crystal place and break");
        add("AutoTotem","Combat","Swaps totem to offhand");
        add("Velocity","Combat","Reduces knockback");
        add("Criticals","Combat","Forces critical hits");
        add("Sprint","Movement","Auto sprint");
        add("NoFall","Movement","Prevents fall damage");
        add("Speed","Movement","Increases speed");
        add("Jesus","Movement","Walks on water");
        add("Spider","Movement","Climbs walls");
        add("FullBright","Visuals","Max brightness");
        add("ESP","Visuals","Entity ESP");
    }
    private static void add(String n,String c,String d){ MODULES.add(new Module(n,c,d)); }
    public static List<Module> getByCategory(String cat){ return MODULES.stream().filter(m->m.category.equals(cat)).collect(Collectors.toList()); }
    public static Module get(String name){ return MODULES.stream().filter(m->m.name.equals(name)).findFirst().orElse(null); }
}
