package com.gavdlc.gui;
import com.gavdlc.font.WildFontRenderer;
import com.gavdlc.module.Module;
import com.gavdlc.module.ModuleManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.List;
public class ClickGuiScreen extends Screen {
    private static final String[] CATEGORIES = {"Combat","Movement","Visuals","Player","Misc"};
    private String selected = "Combat";
    private int scroll = 0;
    private static final int BORDER = 0xFF3A6BFF, BG = 0xE0101018, PANEL = 0xCC0A0A12, ACCENT = 0xFF4A7AFF, TEXT = 0xFFFFFFFF, TEXT_DIM = 0xFFAAAAAA, ENABLED = 0xFF4AFF6A, HOVER = 0x33FFFFFF;
    public ClickGuiScreen() { super(Text.literal("GaVDLC")); }
    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        WildFontRenderer.ensureLoaded();
        ctx.fill(0,0,width,height,0x80000000);
        int tw = Math.min(width-40,720), th = Math.min(height-40,420);
        int x = (width-tw)/2, y = (height-th)/2;
        ctx.fill(x-3,y-3,x+tw+3,y+th+3,BORDER);
        ctx.fill(x,y,x+tw,y+th,BG);
        int sideW = (int)(tw*0.28);
        ctx.fill(x,y,x+sideW,y+th,PANEL);
        ctx.fill(x+sideW,y,x+sideW+2,y+th,BORDER);
        int cy = y+16;
        for (String cat : CATEGORIES) {
            boolean sel = cat.equals(selected);
            boolean hov = mx>=x && mx<=x+sideW && my>=cy && my<=cy+28;
            if (sel) ctx.fill(x+4,cy,x+sideW-4,cy+28,0x55FFFFFF);
            else if (hov) ctx.fill(x+4,cy,x+sideW-4,cy+28,HOVER);
            WildFontRenderer.draw(ctx, cat, x+16, cy+8, sel?ACCENT:TEXT, 1f);
            cy += 36;
        }
        int rx = x+sideW+8, rw = tw-sideW-16;
        WildFontRenderer.draw(ctx, selected, rx, y+10, ACCENT, 1f);
        List<Module> mods = ModuleManager.getByCategory(selected);
        int myy = y+32-scroll;
        for (Module m : mods) {
            if (myy+24 > y+th-8) break;
            if (myy >= y+28) {
                boolean hov = mx>=rx && mx<=rx+rw-8 && my>=myy && my<=myy+22;
                if (hov) ctx.fill(rx,myy,rx+rw-8,myy+22,HOVER);
                WildFontRenderer.draw(ctx, m.name, rx+8, myy+4, m.enabled?ENABLED:TEXT, 1f);
                WildFontRenderer.draw(ctx, m.description, rx+120, myy+4, TEXT_DIM, 1f);
                WildFontRenderer.draw(ctx, m.enabled?"ON":"OFF", rx+rw-40, myy+4, m.enabled?ENABLED:0xFFFF5555, 1f);
            }
            myy += 26;
        }
        WildFontRenderer.draw(ctx, "GaVDLC", x+8, y+th-16, TEXT_DIM, 1f);
        super.render(ctx,mx,my,delta);
    }
    public boolean mouseClicked(double mx, double my, int btn) {
        int tw = Math.min(width-40,720), th = Math.min(height-40,420);
        int x = (width-tw)/2, y = (height-th)/2, sideW = (int)(tw*0.28);
        int cy = y+16;
        for (String cat : CATEGORIES) {
            if (mx>=x && mx<=x+sideW && my>=cy && my<=cy+28) { selected=cat; scroll=0; return true; }
            cy += 36;
        }
        int rx = x+sideW+8, rw = tw-sideW-16;
        List<Module> mods = ModuleManager.getByCategory(selected);
        int myy = y+32-scroll;
        for (Module m : mods) {
            if (mx>=rx && mx<=rx+rw-8 && my>=myy && my<=myy+22) { if(btn==0) m.toggle(); return true; }
            myy += 26;
        }
        return false;
    }
    @Override public boolean mouseScrolled(double mx,double my,double ha,double va){ scroll=Math.max(0,scroll-(int)(va*20)); return true; }
    @Override public boolean shouldPause(){ return false; }
}
