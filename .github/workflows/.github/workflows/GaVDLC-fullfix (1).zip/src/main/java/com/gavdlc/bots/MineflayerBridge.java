package com.gavdlc.bots;
import com.gavdlc.module.Settings;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
/**
 * Sends bot commands to a remote mineflayer backend so bots run off-PC.
 * Set bots.backend URL in Settings.
 */
public final class MineflayerBridge {
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    public static void send(String command) {
        String backend = Settings.getStr("bots.backend", "");
        if (backend.isEmpty()) return;
        try {
            String body = "{\"cmd\":\"" + command.replace("\"", "\\\"") + "\",\"mode\":\"" + Settings.getStr("bots.mode", "ULTRASAFE") + "\"}";
            HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(backend + "/api/command"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .timeout(Duration.ofSeconds(5))
                .build();
            HTTP.sendAsync(req, HttpResponse.BodyHandlers.discarding());
        } catch (Throwable ignored) {}
    }
    public static void spawnBots(String host, int port, int count) {
        String backend = Settings.getStr("bots.backend", "");
        if (backend.isEmpty()) return;
        try {
            String body = "{\"host\":\"" + host + "\",\"port\":" + port + ",\"count\":" + count + ",\"mode\":\"" + Settings.getStr("bots.mode", "ULTRASAFE") + "\"}";
            HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(backend + "/api/spawn"))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .timeout(Duration.ofSeconds(10))
                .build();
            HTTP.sendAsync(req, HttpResponse.BodyHandlers.discarding());
        } catch (Throwable ignored) {}
    }
}
