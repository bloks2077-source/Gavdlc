package com.gavdlc.bots;

import com.gavdlc.module.Settings;
import java.io.*;
import java.util.*;

/**
 * Runs bots locally on the user's PC.
 * ULTRASAFE = chat relay only (minimal CPU/RAM).
 * Default = full features.
 */
public final class LocalBotRunner {
    private static Process nodeProcess;
    private static final List<String> activeBots = new ArrayList<>();

    public static void start(String host, int port, int count, String mode) {
        stop();
        activeBots.clear();
        int n = Math.min(count, 150);
        for (int i = 0; i < n; i++) activeBots.add("Bot_" + (i + 1));
        BotManager.BOTS.clear();
        BotManager.BOTS.addAll(activeBots);
        // In ULTRASAFE we don't spawn real processes — just simulate chat relay
        if ("ULTRASAFE".equals(mode)) {
            BotManager.CHAT_LOG.add("[System] ULTRASAFE: " + n + " bots ready (chat only, ~" + (n * 20) + " MB)");
            return;
        }
        // Default: try to spawn local mineflayer if node is available
        try {
            File script = extractScript();
            if (script != null && isNodeAvailable()) {
                nodeProcess = new ProcessBuilder("node", script.getAbsolutePath(),
                    "--host", host, "--port", String.valueOf(port), "--count", String.valueOf(n), "--mode", mode)
                    .redirectErrorStream(true).start();
                BotManager.CHAT_LOG.add("[System] Started " + n + " local bots");
            } else {
                BotManager.CHAT_LOG.add("[System] Node.js not found. Using simulated bots.");
            }
        } catch (Throwable t) {
            BotManager.CHAT_LOG.add("[System] Local bots: " + t.getMessage());
        }
    }

    public static void stop() {
        if (nodeProcess != null) {
            nodeProcess.destroy();
            nodeProcess = null;
        }
        activeBots.clear();
    }

    public static void chat(String msg) {
        // Relay to all bots (ULTRASAFE = just log, Default = send to process)
        for (String bot : activeBots) {
            BotManager.CHAT_LOG.add("[" + bot + "] " + msg);
        }
        if (nodeProcess != null && nodeProcess.isAlive()) {
            try {
                nodeProcess.getOutputStream().write((msg + "\n").getBytes());
                nodeProcess.getOutputStream().flush();
            } catch (Throwable ignored) {}
        }
    }

    private static boolean isNodeAvailable() {
        try {
            Process p = new ProcessBuilder("node", "--version").start();
            return p.waitFor() == 0;
        } catch (Throwable t) { return false; }
    }

    private static File extractScript() {
        try {
            File f = new File(System.getProperty("java.io.tmpdir"), "gavdlc_bots.js");
            if (!f.exists()) {
                try (InputStream is = LocalBotRunner.class.getResourceAsStream("/assets/gavdlc/colab_bots.js")) {
                    if (is == null) return null;
                    try (FileOutputStream fos = new FileOutputStream(f)) {
                        is.transferTo(fos);
                    }
                }
            }
            return f;
        } catch (Throwable t) { return null; }
    }
}
