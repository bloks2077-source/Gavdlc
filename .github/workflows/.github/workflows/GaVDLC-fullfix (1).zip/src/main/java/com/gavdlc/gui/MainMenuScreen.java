package com.gavdlc.gui;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
public class MainMenuScreen extends Screen {
    public MainMenuScreen(){ super(Text.literal("GaVDLC")); }
    @Override protected void init() {
        int cx=width/2, by=height/2+20;
        addDrawableChild(ButtonWidget.builder(Text.literal("Singleplayer"), b->client.setScreen(new SelectWorldScreen(this))).dimensions(cx-100,by,200,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Multiplayer"), b->client.setScreen(new MultiplayerScreen(this))).dimensions(cx-100,by+26,200,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Options"), b->client.setScreen(new net.minecraft.client.gui.screen.option.OptionsScreen(this,client.options))).dimensions(cx-100,by+52,200,20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Quit"), b->client.scheduleStop()).dimensions(cx-100,by+78,200,20).build());
    }
    @Override public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0,0,width,height,0xFF0A0A14);
        ctx.drawCenteredTextWithShadow(textRenderer, "GaVDLC", width/2, height/2-40, 0xFF3A6BFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "Fabric 1.21.11", width/2, height/2-20, 0xFF888888);
        super.render(ctx,mx,my,delta);
    }
}
