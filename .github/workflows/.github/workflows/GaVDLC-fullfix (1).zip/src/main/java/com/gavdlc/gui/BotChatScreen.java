package com.gavdlc.gui;

import com.gavdlc.bots.BotManager;
import com.gavdlc.bots.CommandHelper;
import com.gavdlc.module.Settings;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;

public class BotChatScreen extends Screen {
    private TextFieldWidget chatInput;
    private TextFieldWidget backendInput;
    private String status = "";

    public BotChatScreen() {
        super(Text.literal("Bots"));
    }

    @Override
    protected void init() {
        int cx = width / 2;
        // Backend URL field
        backendInput = new TextFieldWidget(textRenderer, cx - 150, height - 60, 300, 18, Text.literal("Backend"));
        backendInput.setMaxLength(200);
        backendInput.setText(Settings.getStr("bots.backend", ""));
        backendInput.setPlaceholder(Text.literal("Colab URL (http://IP:8080)"));
        addDrawableChild(backendInput);

        // Chat input
        chatInput = new TextFieldWidget(textRenderer, cx - 150, height - 36, 300, 18, Text.literal("Chat"));
        chatInput.setMaxLength(256);
        chatInput.setPlaceholder(Text.literal("Type /help or message..."));
        addDrawableChild(chatInput);
        setInitialFocus(chatInput);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0xC0101018);
        // Title
        ctx.drawCenteredTextWithShadow(textRenderer, "Bots [" + Settings.getStr("bots.mode", "ULTRASAFE") + "]", width / 2, 8, 0xFF4A7AFF);
        // Suggestions
        List<String> sugg = BotManager.suggestions;
        int sy = height - 80;
        for (int i = 0; i < Math.min(sugg.size(), 5); i++) {
            ctx.drawText(textRenderer, sugg.get(i), width / 2 - 150, sy - (i * 12), 0xFFAAAAAA, false);
        }
        // Chat log
        int ly = 28;
        int start = Math.max(0, BotManager.CHAT_LOG.size() - 18);
        for (int i = start; i < BotManager.CHAT_LOG.size() && ly < height - 90; i++) {
            ctx.drawText(textRenderer, BotManager.CHAT_LOG.get(i), 10, ly, 0xFFFFFFFF, false);
            ly += 12;
        }
        // Status
        if (!status.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, status, width / 2, height - 78, 0xFF4AFF6A);
        }
        super.render(ctx, mx, my, delta);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mod) {
        if (key == 257 || key == 335) { // Enter
            if (backendInput.isFocused()) {
                String url = backendInput.getText().trim();
                Settings.setStr("bots.backend", url);
                status = url.isEmpty() ? "Backend cleared" : "Backend set: " + url;
                return true;
            }
            if (chatInput.isFocused()) {
                String msg = chatInput.getText().trim();
                if (!msg.isEmpty()) {
                    BotManager.sendChat(msg);
                    chatInput.setText("");
                }
                return true;
            }
        }
        if (key == 256) { // Escape
            close();
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char c, int mod) {
        if (chatInput.isFocused()) {
            BotManager.onInput(chatInput.getText() + c);
        }
        return false;
    }

    @Override
    public boolean shouldPause() { return false; }
}
