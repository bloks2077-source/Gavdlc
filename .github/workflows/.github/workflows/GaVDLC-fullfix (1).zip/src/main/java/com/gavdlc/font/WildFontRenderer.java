package com.gavdlc.font;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
public final class WildFontRenderer {
    public static void ensureLoaded() {}
    public static void draw(DrawContext ctx, String text, int x, int y, int color, float scale) {
        ctx.drawText(MinecraftClient.getInstance().textRenderer, text == null ? "" : text, x, y, color, false);
    }
    public static int width(String text) {
        return MinecraftClient.getInstance().textRenderer.getWidth(text == null ? "" : text);
    }
}
