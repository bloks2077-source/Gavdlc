package com.gavdlc.logic;

import com.gavdlc.module.Settings;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class AutoWinLogic {
    private AutoWinLogic() {}
    private static long lastAction;
    private static long lastEat;
    private static long lastPearl;
    private static long lastCrystal;

    public static void tick(MinecraftClient mc) {
        if (!Settings.getBool("autowin.enabled", false)) return;
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        float myHp = mc.player.getHealth() + 0;
        LivingEntity target = findNearest(mc, Settings.get("autowin.range", 6f));

        // Eat apple if low HP
        if (myHp < Settings.get("autowin.eatHp", 10f) && System.currentTimeMillis() - lastEat > 800) {
            if (eatApple(mc)) { lastEat = System.currentTimeMillis(); return; }
        }

        // Flee or pearl if very low
        if (myHp < Settings.get("autowin.fleeHp", 6f) && target != null) {
            if (System.currentTimeMillis() - lastPearl > 2000) {
                if (throwPearl(mc, target)) { lastPearl = System.currentTimeMillis(); return; }
            }
            flee(mc, target);
            return;
        }

        if (target == null) return;

        // Max aim speed
        lookAt(mc, target.getPos().add(0, target.getHeight() * 0.5, 0), Settings.get("autowin.aimSpeed", 1f));

        // Only crits: jump then hit
        boolean canCrit = !mc.player.isOnGround() && mc.player.getVelocity().y < 0 && mc.player.fallDistance > 0;
        if (!canCrit && mc.player.isOnGround()) {
            mc.player.jump();
            return;
        }

        // Crystal if target low or we have advantage
        if (target.getHealth() < Settings.get("autowin.crystalHp", 14f) && System.currentTimeMillis() - lastCrystal > 100) {
            if (doCrystal(mc, target)) { lastCrystal = System.currentTimeMillis(); return; }
        }

        // 360 crit hit
        if (canCrit && System.currentTimeMillis() - lastAction > (1000f / Settings.get("autowin.cps", 10f))) {
            float range = Settings.get("autowin.range", 6f);
            Box box = mc.player.getBoundingBox().expand(range);
            for (Entity e : mc.world.getOtherEntities(mc.player, box, ent -> ent instanceof LivingEntity && ent.isAlive())) {
                if (mc.player.distanceTo(e) <= range) {
                    try { mc.interactionManager.attackEntity(mc.player, e); } catch (Throwable ignored) {}
                }
            }
            mc.player.swingHand(Hand.MAIN_HAND);
            lastAction = System.currentTimeMillis();
        }
    }

    private static LivingEntity findNearest(MinecraftClient mc, float range) {
        LivingEntity best = null; double bestD = range;
        Box box = mc.player.getBoundingBox().expand(range);
        for (Entity e : mc.world.getOtherEntities(mc.player, box, ent -> ent instanceof LivingEntity && ent.isAlive())) {
            if (e instanceof PlayerEntity pe && (pe.isSpectator() || pe.isCreative())) continue;
            double d = mc.player.distanceTo(e);
            if (d < bestD) { bestD = d; best = (LivingEntity) e; }
        }
        return best;
    }

    private static boolean eatApple(MinecraftClient mc) {
        int slot = findItem(mc, Items.ENCHANTED_GOLDEN_APPLE);
        if (slot < 0) slot = findItem(mc, Items.GOLDEN_APPLE);
        if (slot < 0) return false;
        if (slot < 9) {
            mc.player.getInventory().setSelectedSlot(slot);
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            return true;
        }
        return false;
    }

    private static boolean throwPearl(MinecraftClient mc, LivingEntity from) {
        int slot = findItem(mc, Items.ENDER_PEARL);
        if (slot < 0 || slot >= 9) return false;
        mc.player.getInventory().setSelectedSlot(slot);
        // Look away from target
        Vec3d away = mc.player.getPos().subtract(from.getPos()).normalize();
        lookAt(mc, mc.player.getPos().add(away.multiply(10)), 1f);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        return true;
    }

    private static void flee(MinecraftClient mc, LivingEntity from) {
        Vec3d away = mc.player.getPos().subtract(from.getPos()).normalize();
        mc.player.setVelocity(away.x * 0.4, mc.player.getVelocity().y, away.z * 0.4);
        mc.player.setSprinting(true);
    }

    private static boolean doCrystal(MinecraftClient mc, LivingEntity target) {
        // Break existing
        Box box = mc.player.getBoundingBox().expand(5);
        for (Entity e : mc.world.getOtherEntities(mc.player, box, ent -> ent instanceof EndCrystalEntity)) {
            mc.interactionManager.attackEntity(mc.player, e);
            mc.player.swingHand(Hand.MAIN_HAND);
            return true;
        }
        // Place crystal on obby near target
        int cSlot = findItem(mc, Items.END_CRYSTAL);
        if (cSlot >= 0 && cSlot < 9) {
            BlockPos base = findObbyNear(mc, target.getBlockPos(), 3);
            if (base != null) {
                selectSlot(mc, cSlot);
                lookAt(mc, Vec3d.ofCenter(base).add(0, 0.5, 0), 1f);
                BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(base).add(0, 0.5, 0), Direction.UP, base, false);
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
                mc.player.swingHand(Hand.MAIN_HAND);
                return true;
            }
        }
        // Place obby
        int oSlot = findItem(mc, Items.OBSIDIAN);
        if (oSlot >= 0 && oSlot < 9) {
            BlockPos spot = target.getBlockPos().add(1, 0, 0);
            if (mc.world.getBlockState(spot).isAir() && mc.world.getBlockState(spot.down()).isSolidBlock(mc.world, spot.down())) {
                selectSlot(mc, oSlot);
                lookAt(mc, Vec3d.ofCenter(spot.down()).add(0, 0.5, 0), 1f);
                BlockHitResult hit = new BlockHitResult(Vec3d.ofCenter(spot.down()).add(0, 0.5, 0), Direction.UP, spot.down(), false);
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
                mc.player.swingHand(Hand.MAIN_HAND);
                return true;
            }
        }
        return false;
    }

    private static BlockPos findObbyNear(MinecraftClient mc, BlockPos center, int r) {
        for (int x = -r; x <= r; x++) for (int y = -1; y <= 1; y++) for (int z = -r; z <= r; z++) {
            BlockPos p = center.add(x, y, z);
            if (mc.world.getBlockState(p).isOf(Blocks.OBSIDIAN) && mc.world.getBlockState(p.up()).isAir()) return p;
        }
        return null;
    }

    private static void lookAt(MinecraftClient mc, Vec3d target, float speed) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d diff = target.subtract(eye);
        float yaw = (float) Math.toDegrees(Math.atan2(-diff.x, diff.z));
        float pitch = (float) -Math.toDegrees(Math.atan2(diff.y, Math.hypot(diff.x, diff.z)));
        mc.player.setYaw(MathHelper.lerpAngleDegrees(speed, mc.player.getYaw(), yaw));
        mc.player.setPitch(MathHelper.clamp(MathHelper.lerp(speed, mc.player.getPitch(), pitch), -90, 90));
    }

    private static int findItem(MinecraftClient mc, net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        return -1;
    }

    private static void selectSlot(MinecraftClient mc, int slot) {
        if (slot != mc.player.getInventory().getSelectedSlot() && slot >= 0 && slot < 9 && mc.getNetworkHandler() != null) {
            mc.player.getInventory().setSelectedSlot(slot);
            mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        }
    }
}
